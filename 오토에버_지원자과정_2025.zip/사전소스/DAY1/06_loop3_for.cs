using static System.Console;

// �ٽ� : for ��

int[] x = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
