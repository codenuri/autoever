﻿using static System.Console;

// Car 타입의 객체가 몇개나 생성되었는지 알고 싶다.

class Car 
{
    private int speed = 0;  
}

class Program
{
    public static void Main()
    {
        Car c1 = new Car();
        Car c2 = new Car();

    }
}