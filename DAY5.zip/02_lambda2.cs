using static System.Console;

// lambda expression 장점
class Program
{
    static bool IsMultipleOf(int n) { return n % 3 == 0; }

    public static void Main()
    {
        int[] array = { 1, 3, 6, 4, 5 };

        // �Ʒ� �ڵ�� "3"�� ��� ã�� 
        int idx = Array.FindIndex(array, IsMultipleOf);
    }
}
