using System.Windows;

class MainFrame : Window
{
	public MainFrame() 
	{
	}
}

class App : Application
{
    [STAThread]
    public static void Main()
    {
		App app = new App();

        MainFrame w = new MainFrame();
        w.Title = "Hello, WPF";
        w.Show();
        
        app.Run();
    }
}