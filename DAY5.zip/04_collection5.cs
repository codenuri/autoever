﻿using System;
using System.Collections;
using System.Collections.Generic;
using static System.Console;

// Dictionary - key 값을 가지고 value 를 보관하는 collection

class Program
{
    public static void Main()
    {
        Dictionary<string, string> dic = new Dictionary<string, string>();
                
    }
}
