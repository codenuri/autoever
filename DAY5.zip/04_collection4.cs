﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using static System.Console;

class Program
{
    public static void Main()
    {
        List<int> c1 = new List<int>();
        LinkedList<int> c2 = new LinkedList<int>();

        for (int i = 0; i < 10; i++)
        {
            c1.Add(i);
            c2.AddLast(i);
        }
        //---------------------------------------------
        // 컬렉션의 모든 요소에 접근하는 3가지 방법
        // #1. foreach 사용 


        // #2. 반복자(열거자) 사용 


        // #3. for 와 [] 사용..

    }
}