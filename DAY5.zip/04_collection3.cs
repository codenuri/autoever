﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using static System.Console;

// 반복자
class Program
{
    public static void Main()
    {
        List<int>       c1 = new List<int>();
        LinkedList<int> c2 = new LinkedList<int>();

        for(int i = 0; i < 10; i++)
        {
            c1.Add(i);
            c2.AddLast(i);
        }
		// ---------------------------------------------
        // List : [] 연산자로 요소 접근 가능
        // LinkedList : [] 연산자 사용 못함
        c1[0] = 0; // ok
//      c2[0] = 0; // error

        // 반복자(열거자)
        // => 컬렉션의 모든 요소를 순차적으로 접근할때 사용하는 도구
        // => 모든 컬렉션의 반복자(열거자)는 사용법이 동일

    }
}