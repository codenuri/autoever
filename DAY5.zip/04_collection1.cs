﻿using System;
using System.Collections;
using System.Collections.Generic;
using static System.Console;

// Collection ( 185 ~ )
// => 여러개의 값을 보관하는 타입

class Program
{
    public static void Main()
    {
        // #1. 배열 
        int[] x = { 1, 2, 3 };


        // #2. List : 크기 변경이 가능한 동적 배열
        List<int> s = new List<int>() { 1, 2, 3 }; 

       

    }
}

