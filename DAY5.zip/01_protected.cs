class Shape
{
    private   int color1 = 0;
	protected int color2 = 0;
	public    int color3 = 0;
}

class Rect : Shape
{
    public void Draw()
    {
        int c1 = color1; // ?
		int c2 = color2; // ?
		int c3 = color3; // ?
    }
}

class Program 
{     
    public static void Main()
    {
        Shape s = new Shape();
       	int c1 = s.color1; // ?	
		int c2 = s.color2; // ?	
		int c3 = s.color3; // ?	
    }

}
