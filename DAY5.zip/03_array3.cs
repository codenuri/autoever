﻿using static System.Console;

int[] arr = { 1, 2, 3, 4, 5 };

// #1. 배열 타입 변수는 몇가지 속성을 제공한다



// #2. 배열에 관한 연산은 "Array 클래스의 static method" 활용
