﻿using static System.Console;

class Program
{
    public static void Main()
    {
        int[] array = { 1, 3, 6, 4, 5 };

        int k = 3;
        int idx1 = Array.FindIndex(array, (int n) => { return n % k == 0; });


    }
}
