﻿using System;
using System.IO;
using System.Text;

// C# 학습
// 1. 다양한 문법을 공부 하세요(property, delegate, interface... )
// 2. 다양한 표준 라이브러리(타입)의 사용법을 알아야 합니다.
// => File 작업 : FileStream
// => 네트워크  : 수백개의 관련 클래스
// => UI : WPF 등의 라이브러리

class Program
{
    static void Main()
    {
		// File 작업을 하려면
		
    }
}
