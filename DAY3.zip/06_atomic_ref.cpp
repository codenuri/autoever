#include <iostream>
#include <thread>
#include <atomic>

struct Machine
{
	int data{ 0 };
	int count{ 0 };
};
Machine m;

void foo()
{
	int& cnt = m.count;

	for (int i = 0; i < 1000000; i++)
	{
		++cnt;
	}
}
int main()
{	
	std::thread t1(foo), t2(foo), t3(foo);

	t1.join();
	t2.join();
	t3.join();

	std::cout << m.count << std::endl;
}
