﻿// abstract method : method 앞에 abstract 키워드를 붙인 메소드. 메소드 구현부이 없다.

// abstract class 
// 정의 : abstract method 가 한개 이상있으면 클래스 에도 abstract 를 붙여야 한다 
// 특징 : 
// 의도 : 

abstract class Shape
{
    private int color = 0;
    public void SetColor(int c) { color = c; }
    public abstract void Draw();
}

class Rect : Shape
{
}

class Program
{ 
    public static void Main()
    {
        Shape s = new Shape();
        Rect r = new Rect();
    }
}